package com.login.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.login.demo.dao.UserDetail;
import com.login.demo.model.RegistrationDeatil;

@Controller
public class Registration {
	
	@Autowired
	UserDetail user;
	
	@RequestMapping("/login")
	public String login()
	{
		return "login.jsp";
	}
	
	@RequestMapping("/addData")
	public String addData(RegistrationDeatil regs)
	{
		user.save(regs);
		return "login.jsp";
	}
	
	@RequestMapping("/getData")
	public ModelAndView getData(@RequestParam String username)
	{
		ModelAndView mv= new ModelAndView("showdata.jsp");
		RegistrationDeatil regs=user.findById(username).orElse(new RegistrationDeatil());
		mv.addObject(regs);
		return mv;
	}

}
