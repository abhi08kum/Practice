package com.login.demo.dao;

import org.springframework.data.repository.CrudRepository;

import com.login.demo.model.RegistrationDeatil;

public interface UserDetail extends CrudRepository<RegistrationDeatil, String>
{
	

}
