package com.login.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class RegistrationDeatil {
	
	@Id
	private String username;
	private String fname;
	private String lname;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	
	@Override
	public String toString() {
		return "RegistrationDeatil [fname=" + fname + ", lname=" + lname + ", username=" + username + "]";
	}
	


}
