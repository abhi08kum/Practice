	insert into RegistrationDeatil values ('abhi','Abhishek','Kumar');
	insert into RegistrationDeatil values ('neh','Neha','Kumari');
	insert into RegistrationDeatil values ('kar','Kartik','Kumar');
	insert into RegistrationDeatil values ('ani','Anish','Kumar');
	insert into RegistrationDeatil values ('pushu','Pushkar','Kumar');
